//#region src/parsers/dbcParser.ts
function parseDbc(dbcContent) {
	const messages = [];
	const errors = [];
	const lines = dbcContent.split(/\r?\n/);
	let currentMessage = null;
	const messageMap = /* @__PURE__ */ new Map();
	const signalComments = /* @__PURE__ */ new Map();
	const messageComments = /* @__PURE__ */ new Map();
	const boRegex = /^\s*BO_\s+(\d+)\s+([A-Za-z0-9_]+)\s*:\s*(\d+)\s+([A-Za-z0-9_]+)/;
	const sgRegex = /^\s*SG_\s+([A-Za-z0-9_]+)(?:\s+([Mm0-9]+))?\s*:\s*(\d+)\|(\d+)@([01])([+-])\s*\(([-+0-9.eE]+),([+-0-9.eE]+)\)\s*\[([-+0-9.eE]+)\|([-+0-9.eE]+)\]\s*"([^"]*)"\s*([A-Za-z0-9_,]+)?/;
	const cmBoRegex = /^\s*CM_\s+BO_\s+(\d+)\s+"([^"]*)";?/;
	const cmSgRegex = /^\s*CM_\s+SG_\s+(\d+)\s+([A-Za-z0-9_]+)\s+"([^"]*)";?/;
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i].trim();
		if (!line || line.startsWith("//")) continue;
		const boMatch = line.match(boRegex);
		if (boMatch) {
			const id = parseInt(boMatch[1], 10) & 536870911;
			currentMessage = {
				id,
				hexId: `0x${id.toString(16).toUpperCase()}`,
				name: boMatch[2],
				dlc: parseInt(boMatch[3], 10),
				sender: boMatch[4],
				signals: []
			};
			messages.push(currentMessage);
			messageMap.set(id, currentMessage);
			continue;
		}
		const sgMatch = line.match(sgRegex);
		if (sgMatch) {
			if (!currentMessage) {
				errors.push(`Line ${i + 1}: Found signal definition before any message (BO_)`);
				continue;
			}
			const sigName = sgMatch[1];
			const multiplexerIndicator = sgMatch[2];
			const startBit = parseInt(sgMatch[3], 10);
			const length = parseInt(sgMatch[4], 10);
			const endianness = sgMatch[5] === "1" ? "little" : "big";
			const isSigned = sgMatch[6] === "-";
			const scale = parseFloat(sgMatch[7]);
			const offset = parseFloat(sgMatch[8]);
			const min = parseFloat(sgMatch[9]);
			const max = parseFloat(sgMatch[10]);
			const unit = sgMatch[11] || "";
			const receiver = sgMatch[12] || "VHAL";
			const signal = {
				id: `${currentMessage.hexId}:${sigName}`,
				name: sigName,
				messageId: currentMessage.id,
				messageName: currentMessage.name,
				startBit,
				length,
				endianness,
				isSigned,
				scale: isNaN(scale) ? 1 : scale,
				offset: isNaN(offset) ? 0 : offset,
				min: isNaN(min) ? 0 : min,
				max: isNaN(max) ? 100 : max,
				unit,
				receiver,
				multiplexerIndicator
			};
			currentMessage.signals.push(signal);
			continue;
		}
		const cmSgMatch = line.match(cmSgRegex);
		if (cmSgMatch) {
			const msgId = parseInt(cmSgMatch[1], 10) & 536870911;
			const sigName = cmSgMatch[2];
			const comment = cmSgMatch[3];
			signalComments.set(`${msgId}:${sigName}`, comment);
			continue;
		}
		const cmBoMatch = line.match(cmBoRegex);
		if (cmBoMatch) {
			const msgId = parseInt(cmBoMatch[1], 10) & 536870911;
			const comment = cmBoMatch[2];
			messageComments.set(msgId, comment);
			continue;
		}
	}
	for (const msg of messages) {
		if (messageComments.has(msg.id)) msg.comment = messageComments.get(msg.id);
		for (const sig of msg.signals) {
			const key = `${msg.id}:${sig.name}`;
			if (signalComments.has(key)) sig.comment = signalComments.get(key);
		}
	}
	return {
		messages,
		errors,
		totalSignals: messages.reduce((acc, m) => acc + m.signals.length, 0)
	};
}
function parseJsonMatrix(jsonContent) {
	try {
		const data = JSON.parse(jsonContent);
		const messages = [];
		const errors = [];
		const rawList = Array.isArray(data) ? data : data.messages || data.frames || [];
		for (const raw of rawList) {
			const id = typeof raw.id === "string" ? parseInt(raw.id, 16) : Number(raw.id || 0);
			const hexId = `0x${id.toString(16).toUpperCase()}`;
			const name = raw.name || `MSG_${hexId}`;
			const dlc = Number(raw.dlc || 8);
			const sender = raw.sender || "ECU";
			const signals = [];
			const rawSignals = raw.signals || [];
			for (const s of rawSignals) signals.push({
				id: `${hexId}:${s.name}`,
				name: s.name,
				messageId: id,
				messageName: name,
				startBit: Number(s.startBit ?? s.start_bit ?? 0),
				length: Number(s.length ?? s.bit_length ?? 8),
				endianness: s.endianness === "big" || s.byte_order === "motorola" ? "big" : "little",
				isSigned: Boolean(s.isSigned ?? s.is_signed),
				scale: Number(s.scale ?? 1),
				offset: Number(s.offset ?? 0),
				min: Number(s.min ?? 0),
				max: Number(s.max ?? 100),
				unit: s.unit || "",
				receiver: s.receiver || "VHAL",
				comment: s.comment || s.description
			});
			messages.push({
				id,
				hexId,
				name,
				dlc,
				sender,
				signals,
				comment: raw.comment || raw.description
			});
		}
		return {
			messages,
			errors,
			totalSignals: messages.reduce((acc, m) => acc + m.signals.length, 0)
		};
	} catch (err) {
		return {
			messages: [],
			errors: [`Invalid JSON matrix: ${err?.message || "Parse error"}`],
			totalSignals: 0
		};
	}
}
var SAMPLE_POWERTRAIN_DBC = `
VERSION ""

NS_ :
	NS_DESC_
	CM_
	BA_DEF_
	BA_
	VAL_
	CAT_DEF_
	CAT_
	FILTER
	BA_DEF_DEF_
	EV_DATA_
	ENVVAR_DATA_
	SGTYPE_
	SGTYPE_VAL_
	BA_DEF_SGTYPE_
	BA_SGTYPE_
	SIG_TYPE_REF_
	VAL_TABLE_
	SIG_GROUP_
	SIG_VALTYPE_
	SIGTYPE_VALTYPE_
	BO_TX_BU_
	BA_DEF_REL_
	BA_REL_
	BA_DEF_DEF_REL_
	BU_SG_REL_
	BU_EV_REL_
	BU_BO_REL_
	SG_MUL_VAL_

BS_:

BU_: ECM ESC BCM BMS HVAC VHAL

BO_ 420 VehicleDynamics: 8 ESC
 SG_ VehicleSpeed : 7|16@0+ (0.01,0) [0|300] "km/h" VHAL
 SG_ SteeringWheelAngle : 23|16@0- (0.1,0) [-900|900] "deg" VHAL
 SG_ BrakePedalPosition : 39|8@0+ (0.39215686,0) [0|100] "%" VHAL
 SG_ YawRate : 47|16@0- (0.01,0) [-100|100] "deg/s" VHAL
 SG_ AbsActive : 56|1@1+ (1,0) [0|1] "" VHAL
 SG_ TractionControlActive : 57|1@1+ (1,0) [0|1] "" VHAL

BO_ 500 EngineStatus: 8 ECM
 SG_ EngineSpeed : 0|16@1+ (0.25,0) [0|8000] "rpm" VHAL
 SG_ EngineCoolantTemp : 16|8@1+ (1,-40) [-40|215] "C" VHAL
 SG_ EngineOilTemp : 24|8@1+ (1,-40) [-40|215] "C" VHAL
 SG_ AcceleratorPedalPos : 32|8@1+ (0.39215686,0) [0|100] "%" VHAL
 SG_ CurrentGear : 40|4@1+ (1,0) [0|10] "gear" VHAL
 SG_ GearSelectorPosition : 44|4@1+ (1,0) [0|15] "enum" VHAL

BO_ 610 BatteryManagement: 8 BMS
 SG_ HighVoltageBatteryLevel : 0|16@1+ (10,0) [0|100000] "Wh" VHAL
 SG_ BatteryChargeDischargeRate : 16|16@1- (100,0) [-150000|150000] "mW" VHAL
 SG_ ChargePortConnected : 32|1@1+ (1,0) [0|1] "" VHAL
 SG_ ChargePortFlapOpen : 33|1@1+ (1,0) [0|1] "" VHAL
 SG_ MaxAcChargeCurrent : 40|8@1+ (0.5,0) [0|100] "A" VHAL
 SG_ RegenerativeBrakingLevel : 48|4@1+ (1,0) [0|3] "level" VHAL

BO_ 720 BodyControlModule: 8 BCM
 SG_ FrontLeftDoorLocked : 0|1@1+ (1,0) [0|1] "" VHAL
 SG_ DriverWindowPosition : 8|8@1+ (0.39215686,0) [0|100] "%" VHAL
 SG_ TurnSignalState : 16|3@1+ (1,0) [0|4] "enum" VHAL
 SG_ HeadlightsMode : 24|3@1+ (1,0) [0|4] "enum" VHAL
 SG_ HazardLightsActive : 32|1@1+ (1,0) [0|1] "" VHAL
 SG_ ParkingBrakeEngaged : 40|1@1+ (1,0) [0|1] "" VHAL

BO_ 830 ClimateControlStatus: 8 HVAC
 SG_ CabinMeasuredTemp : 0|8@1+ (0.5,-40) [-40|85] "C" VHAL
 SG_ DriverTargetTemp : 8|8@1+ (0.5,-40) [-40|85] "C" VHAL
 SG_ BlowerFanSpeed : 16|4@1+ (1,0) [0|7] "step" VHAL
 SG_ AirConditioningActive : 20|1@1+ (1,0) [0|1] "" VHAL
 SG_ DefrosterRearActive : 21|1@1+ (1,0) [0|1] "" VHAL
 SG_ AirRecirculationActive : 22|1@1+ (1,0) [0|1] "" VHAL

CM_ BO_ 420 "Electronic Stability Controller Broadcast Message";
CM_ SG_ 420 VehicleSpeed "Chassis wheel-derived vehicle speed broadcast";
CM_ SG_ 420 SteeringWheelAngle "Steering column optical absolute angular position";
CM_ BO_ 500 "Engine Management ECU High Priority Status Frame";
CM_ SG_ 500 EngineSpeed "Filtered crankshaft rotational frequency";
CM_ BO_ 610 "EV High Voltage Battery Pack State of Health and Charge";
`;
//#endregion
//#region src/parsers/aospCatalog.ts
var AOSP_VHAL_CATALOG = [
	{
		name: "PERF_VEHICLE_SPEED",
		id: 291504647,
		hexId: "0x11600207",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "m/s",
		domain: "Dynamics",
		description: "Vehicle speed in meters per second (m/s). Standard AAOS speed source.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "PERF_ODOMETER",
		id: 291504644,
		hexId: "0x11600204",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "km",
		domain: "Dynamics",
		description: "Current odometer reading in kilometers.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "PERF_STEERING_ANGLE",
		id: 291504648,
		hexId: "0x11600208",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "deg",
		domain: "Dynamics",
		description: "Steering wheel angle in degrees. Positive = counter-clockwise (left).",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "PERF_REAR_STEERING_ANGLE",
		id: 291504649,
		hexId: "0x11600209",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "deg",
		domain: "Dynamics",
		description: "Rear axle steering angle in degrees for four-wheel steering vehicles.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "WHEEL_TICK",
		id: 290456328,
		hexId: "0x11500308",
		dataType: "int64Values",
		areaType: "GLOBAL",
		defaultUnit: "ticks",
		domain: "Dynamics",
		description: "Accumulated wheel ticks per individual wheel for high-precision odometry.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "ACCELERATOR_PEDAL_POSITION",
		id: 291505165,
		hexId: "0x1160040D",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "%",
		domain: "Dynamics",
		description: "Current accelerator pedal depression percentage (0.0 to 100.0%).",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "BRAKE_PEDAL_POSITION",
		id: 291505164,
		hexId: "0x1160040C",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "%",
		domain: "Dynamics",
		description: "Current brake pedal depression percentage (0.0 to 100.0%).",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "VEHICLE_SPEED_DISPLAY_UNITS",
		id: 289407494,
		hexId: "0x11400206",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Dynamics",
		description: "Driver instrument cluster speed unit preference: 1=m/s, 2=km/h, 3=mph.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "ENGINE_RPM",
		id: 291504645,
		hexId: "0x11600205",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "rpm",
		domain: "Powertrain",
		description: "Internal combustion engine crankshaft rotational speed in RPM.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "GEAR_SELECTION",
		id: 289408e3,
		hexId: "0x11400400",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Powertrain",
		description: "Gear selector position (PRNDS): 1=NEUTRAL, 2=REVERSE, 4=PARK, 8=DRIVE.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "CURRENT_GEAR",
		id: 289408001,
		hexId: "0x11400401",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "gear_num",
		domain: "Powertrain",
		description: "Actual engaged transmission mechanical gear ratio (e.g. 1st, 2nd, 3rd gear).",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "PARKING_BRAKE_ON",
		id: 287310850,
		hexId: "0x11200402",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Powertrain",
		description: "Electric parking brake status: true = engaged/on, false = released/off.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "PARKING_BRAKE_AUTO_APPLY",
		id: 287310851,
		hexId: "0x11200403",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Powertrain",
		description: "Automatic parking brake auto-hold engagement switch.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "FUEL_LEVEL",
		id: 291504901,
		hexId: "0x11600305",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "mL",
		domain: "Powertrain",
		description: "Current fuel level in milliliters (mL).",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "FUEL_LEVEL_LOW",
		id: 287310598,
		hexId: "0x11200306",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Powertrain",
		description: "Low fuel warning light threshold trip indicator.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "ENGINE_COOLANT_TEMP",
		id: 291504899,
		hexId: "0x11600303",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "C",
		domain: "Powertrain",
		description: "Engine radiator coolant temperature in degrees Celsius.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "ENGINE_OIL_LEVEL",
		id: 289407748,
		hexId: "0x11400304",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Powertrain",
		description: "Engine motor oil dipstick level status (0=CRITICALLY_LOW, 1=LOW, 2=NORMAL).",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "ENGINE_OIL_TEMP",
		id: 291504903,
		hexId: "0x11600307",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "C",
		domain: "Powertrain",
		description: "Internal engine oil temperature in degrees Celsius.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "EV_BATTERY_LEVEL",
		id: 291504898,
		hexId: "0x11600302",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "Wh",
		domain: "Electrification",
		description: "Current EV high-voltage traction battery stored energy in Watt-hours.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "EV_BATTERY_CHARGE_RATE",
		id: 291504908,
		hexId: "0x1160030C",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "mW",
		domain: "Electrification",
		description: "Instantaneous EV battery charge (+) or discharge (-) rate in milliWatts.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "EV_CHARGE_PORT_CONNECTED",
		id: 287310603,
		hexId: "0x1120030B",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Electrification",
		description: "Electric vehicle charging plug connector insertion status.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "EV_CHARGE_PORT_OPEN",
		id: 287310602,
		hexId: "0x1120030A",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Electrification",
		description: "Motorized EV charging door flap open/closed state.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "EV_CHARGE_CURRENT_DRAW_LIMIT",
		id: 291504909,
		hexId: "0x1160030D",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "A",
		domain: "Electrification",
		description: "Maximum AC charging input current draw limit in Amperes.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "EV_BATTERY_REGENERATIVE_BRAKING_LEVEL",
		id: 289407758,
		hexId: "0x1140030E",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "level",
		domain: "Electrification",
		description: "One-pedal regenerative braking intensity preset level (0=OFF, 1=LOW, 2=HIGH).",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HVAC_TEMPERATURE_CURRENT",
		id: 358614274,
		hexId: "0x15600502",
		dataType: "floatValues",
		areaType: "SEAT",
		defaultUnit: "C",
		domain: "HVAC",
		description: "Actual measured cabin ambient cabin zone temperature in Celsius.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "HVAC_TEMPERATURE_SET",
		id: 358614275,
		hexId: "0x15600503",
		dataType: "floatValues",
		areaType: "SEAT",
		defaultUnit: "C",
		domain: "HVAC",
		description: "User target thermostat set temperature in Celsius per seat zone.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HVAC_FAN_SPEED",
		id: 356517120,
		hexId: "0x15400500",
		dataType: "int32Values",
		areaType: "SEAT",
		defaultUnit: "speed_level",
		domain: "HVAC",
		description: "Cabin blower motor fan speed dial step (0 to 7).",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HVAC_FAN_DIRECTION",
		id: 356517121,
		hexId: "0x15400501",
		dataType: "int32Values",
		areaType: "SEAT",
		defaultUnit: "bitmask",
		domain: "HVAC",
		description: "Airflow vent directing dampers: 1=FACE, 2=FLOOR, 4=DEFROST.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HVAC_AC_ON",
		id: 354419973,
		hexId: "0x15200505",
		dataType: "booleanValues",
		areaType: "SEAT",
		defaultUnit: "bool",
		domain: "HVAC",
		description: "Air conditioning refrigerant compressor clutch power switch.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HVAC_AUTO_ON",
		id: 354419978,
		hexId: "0x1520050A",
		dataType: "booleanValues",
		areaType: "SEAT",
		defaultUnit: "bool",
		domain: "HVAC",
		description: "Automatic climate control algorithm regulation state.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HVAC_RECIRC_ON",
		id: 354419976,
		hexId: "0x15200508",
		dataType: "booleanValues",
		areaType: "SEAT",
		defaultUnit: "bool",
		domain: "HVAC",
		description: "Cabin air recirculation vs fresh outside air intake flap.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HVAC_DEFROSTER",
		id: 320865548,
		hexId: "0x1320050C",
		dataType: "booleanValues",
		areaType: "WINDOW",
		defaultUnit: "bool",
		domain: "HVAC",
		description: "Electric resistive heated wire defroster (Front Windshield / Rear Window).",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HVAC_SEAT_TEMPERATURE",
		id: 356517131,
		hexId: "0x1540050B",
		dataType: "int32Values",
		areaType: "SEAT",
		defaultUnit: "level",
		domain: "HVAC",
		description: "Seat cushion heating (positive) or ventilation cooling (negative) level.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "DOOR_POS",
		id: 373295872,
		hexId: "0x16400B00",
		dataType: "int32Values",
		areaType: "DOOR",
		defaultUnit: "mm",
		domain: "Body",
		description: "Door opening extension offset in millimeters (0 = fully latched closed).",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "DOOR_LOCK",
		id: 371198722,
		hexId: "0x16200B02",
		dataType: "booleanValues",
		areaType: "DOOR",
		defaultUnit: "bool",
		domain: "Body",
		description: "Door solenoid latch lock status: true = locked, false = unlocked.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "WINDOW_POS",
		id: 322964227,
		hexId: "0x13400B03",
		dataType: "int32Values",
		areaType: "WINDOW",
		defaultUnit: "%",
		domain: "Body",
		description: "Power window glass aperture percentage: 0=closed, 100=fully lowered.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "WINDOW_LOCK",
		id: 320867076,
		hexId: "0x13200B04",
		dataType: "booleanValues",
		areaType: "WINDOW",
		defaultUnit: "bool",
		domain: "Body",
		description: "Child-safety master power window switch lockout state.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "SEAT_OCCUPANCY",
		id: 356518692,
		hexId: "0x15400B24",
		dataType: "int32Values",
		areaType: "SEAT",
		defaultUnit: "enum",
		domain: "Body",
		description: "Pressure sensor occupancy classification: 0=EMPTY, 1=CHILD, 2=ADULT.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "SEAT_BELT_BUCKLED",
		id: 354421541,
		hexId: "0x15200B25",
		dataType: "booleanValues",
		areaType: "SEAT",
		defaultUnit: "bool",
		domain: "Body",
		description: "Safety seat belt tongue clicked into buckle receptacle detector.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "TIRE_PRESSURE",
		id: 392168201,
		hexId: "0x17600309",
		dataType: "floatValues",
		areaType: "WHEEL",
		defaultUnit: "kPa",
		domain: "Chassis",
		description: "Tire pressure monitoring system (TPMS) reading in kilopascals (kPa).",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "CRITICALLY_LOW_TIRE_PRESSURE",
		id: 392168202,
		hexId: "0x1760030A",
		dataType: "floatValues",
		areaType: "WHEEL",
		defaultUnit: "kPa",
		domain: "Chassis",
		description: "Minimum emergency threshold level below which flat warning triggers.",
		access: "READ",
		changeMode: "STATIC"
	},
	{
		name: "TRACTION_CONTROL_ACTIVE",
		id: 287310875,
		hexId: "0x1120041B",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Chassis",
		description: "Electronic traction control (TCS) wheel torque limiting active.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "ABS_ACTIVE",
		id: 287310876,
		hexId: "0x1120041C",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Chassis",
		description: "Anti-lock braking system (ABS) hydraulic pulsing valve cycling.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "TURN_SIGNAL_STATE",
		id: 289408008,
		hexId: "0x11400408",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Body",
		description: "Directional indicator stalk switch: 0=NONE, 1=RIGHT, 2=LEFT.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HEADLIGHTS_STATE",
		id: 289410560,
		hexId: "0x11400E00",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Body",
		description: "Exterior headlamp mode: 0=OFF, 1=PARKING, 2=LOW_BEAM, 3=AUTO.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HIGH_BEAM_LIGHTS_STATE",
		id: 289410561,
		hexId: "0x11400E01",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Body",
		description: "High beam high intensity projector lamps: 0=OFF, 1=ON, 2=AUTO.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "HAZARD_LIGHTS_ON",
		id: 287313411,
		hexId: "0x11200E03",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Body",
		description: "Four-way emergency hazard flasher light state.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "FOG_LIGHTS_STATE",
		id: 289410562,
		hexId: "0x11400E02",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Body",
		description: "Front and rear auxiliary bad-weather fog light state.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "CRUISE_CONTROL_ENABLED",
		id: 287313924,
		hexId: "0x11201004",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Sensors",
		description: "Speed cruise control automatic throttle holding active.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "CRUISE_CONTROL_TARGET_SPEED",
		id: 291508230,
		hexId: "0x11601006",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "m/s",
		domain: "Sensors",
		description: "Selected cruise control vehicle speed setpoint in m/s.",
		access: "READ_WRITE",
		changeMode: "ON_CHANGE"
	},
	{
		name: "ADAPTIVE_CRUISE_CONTROL_LEAD_VEHICLE_DISTANCE",
		id: 289411080,
		hexId: "0x11401008",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "mm",
		domain: "Sensors",
		description: "Front radar radar-estimated distance to lead target vehicle in millimeters.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "BLIND_SPOT_WARNING",
		id: 354422784,
		hexId: "0x15201000",
		dataType: "booleanValues",
		areaType: "MIRROR",
		defaultUnit: "bool",
		domain: "Sensors",
		description: "Side radar blind spot warning LED mirror icon indicator alert.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "LANE_DEPARTURE_WARNING_STATE",
		id: 289411081,
		hexId: "0x11401009",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Sensors",
		description: "Vision camera lane marking drift warning state.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "LANE_KEEP_ASSIST_STATE",
		id: 289411082,
		hexId: "0x1140100A",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Sensors",
		description: "Active lane keeping electric power steering torque intervention status.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "AUTOMATIC_EMERGENCY_BRAKING_STATE",
		id: 289411083,
		hexId: "0x1140100B",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Sensors",
		description: "Autonomous collision mitigation emergency automatic braking system status.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "FORWARD_COLLISION_WARNING_STATE",
		id: 289411084,
		hexId: "0x1140100C",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Sensors",
		description: "Imminent frontal vehicle collision audio/visual alert.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "EV_BRAKE_REGENERATION_ACTIVE",
		id: 287310608,
		hexId: "0x11200310",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Electrification",
		description: "Indicates whether regenerative motor retardation is currently producing energy.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "IGNITION_STATE",
		id: 289408010,
		hexId: "0x1140040A",
		dataType: "int32Values",
		areaType: "GLOBAL",
		defaultUnit: "enum",
		domain: "Powertrain",
		description: "Powertrain ignition switch: 0=LOCK, 1=OFF, 2=ACC, 3=ON, 4=START.",
		access: "READ",
		changeMode: "ON_CHANGE"
	},
	{
		name: "ENVIRONMENT_AMBIENT_TEMPERATURE",
		id: 291504917,
		hexId: "0x11600315",
		dataType: "floatValues",
		areaType: "GLOBAL",
		defaultUnit: "C",
		domain: "Sensors",
		description: "Outside vehicle bumper ambient air temperature thermometer in Celsius.",
		access: "READ",
		changeMode: "CONTINUOUS"
	},
	{
		name: "NIGHT_MODE",
		id: 287310855,
		hexId: "0x11200407",
		dataType: "booleanValues",
		areaType: "GLOBAL",
		defaultUnit: "bool",
		domain: "Body",
		description: "Day/night UI theme auto trigger derived from solar light intensity.",
		access: "READ",
		changeMode: "ON_CHANGE"
	}
];
var VHAL_PROPERTY_MAP = new Map(AOSP_VHAL_CATALOG.map((prop) => [prop.name, prop]));
var VHAL_HEX_MAP = new Map(AOSP_VHAL_CATALOG.map((prop) => [prop.hexId.toLowerCase(), prop]));
function getVhalPropertyByName(name) {
	return VHAL_PROPERTY_MAP.get(name);
}
function getVhalPropertyByHexId(hexId) {
	const normalized = hexId.toLowerCase().startsWith("0x") ? hexId.toLowerCase() : `0x${hexId.toLowerCase()}`;
	return VHAL_HEX_MAP.get(normalized);
}
//#endregion
//#region src/parsers/cppReverseParser.ts
function parseCppVhalCode(code) {
	const messages = [];
	const connections = [];
	const reconstructedProperties = [];
	const warnings = [];
	const messageMap = /* @__PURE__ */ new Map();
	const propMap = /* @__PURE__ */ new Map();
	function getOrCreateMessage(msgId, nameHint) {
		if (messageMap.has(msgId)) return messageMap.get(msgId);
		const hexId = `0x${msgId.toString(16).toUpperCase()}`;
		const msg = {
			id: msgId,
			hexId,
			name: nameHint || `MSG_${hexId}`,
			dlc: 8,
			sender: "ECU",
			signals: [],
			comment: "Reverse-engineered from C++ VHAL source"
		};
		messageMap.set(msgId, msg);
		messages.push(msg);
		return msg;
	}
	function resolveProperty(propRef) {
		const enumMatch = propRef.match(/VehicleProperty::([A-Za-z0-9_]+)/);
		const propName = enumMatch ? enumMatch[1] : propRef.trim();
		let prop = getVhalPropertyByName(propName);
		if (!prop) {
			const hexMatch = propRef.match(/0x[0-9a-fA-F]+/);
			if (hexMatch) prop = getVhalPropertyByHexId(hexMatch[0]);
		}
		if (!prop) prop = {
			name: propName,
			id: 428867584 + (propMap.size + 1),
			hexId: `0x${(428867584 + (propMap.size + 1)).toString(16).toUpperCase()}`,
			dataType: "floatValues",
			areaType: "GLOBAL",
			defaultUnit: "custom",
			domain: "Dynamics",
			description: `Custom reverse-engineered property: ${propName}`
		};
		if (!propMap.has(prop.name)) {
			propMap.set(prop.name, prop);
			reconstructedProperties.push(prop);
		}
		return prop;
	}
	const caseRegex = /(?:case\s+(0x[0-9a-fA-F]+|\d+)\s*:|if\s*\(\s*(?:frame\.)?can_id\s*==\s*(0x[0-9a-fA-F]+|\d+)\s*\))/g;
	const matches = [];
	let m;
	while ((m = caseRegex.exec(code)) !== null) {
		const idStr = m[1] || m[2];
		matches.push({
			idStr,
			index: m.index
		});
	}
	for (let i = 0; i < matches.length; i++) {
		const cur = matches[i];
		const startIndex = cur.index;
		const endIndex = i + 1 < matches.length ? matches[i + 1].index : code.length;
		const blockCode = code.slice(startIndex, endIndex);
		const msgId = cur.idStr.startsWith("0x") || cur.idStr.startsWith("0X") ? parseInt(cur.idStr, 16) : parseInt(cur.idStr, 10);
		const commentNameMatch = blockCode.match(/\/\/\s*(?:Message|Frame|CAN\s*ID)?\s*[:\-]?\s*([A-Za-z0-9_]+)/i);
		const canMessage = getOrCreateMessage(msgId, commentNameMatch ? commentNameMatch[1] : void 0);
		const varExtractionMap = /* @__PURE__ */ new Map();
		const varMathMap = /* @__PURE__ */ new Map();
		const lines = blockCode.split(/\r?\n/);
		for (const rawLine of lines) {
			const line = rawLine.trim();
			if (!line || line.startsWith("//")) continue;
			const assignMatch = line.match(/(?:uint\d+_t|int\d+_t|float|double|bool|auto|int|unsigned)\s+([a-zA-Z0-9_]+)\s*=\s*([^;]+);/);
			if (assignMatch) {
				const varName = assignMatch[1];
				const rhs = assignMatch[2].trim();
				if (rhs.includes("frame.data") || rhs.includes("data[")) {
					const byteIndices = [];
					const byteIdxMatches = rhs.matchAll(/(?:frame\.)?data\[(\d+)\]/g);
					for (const b of byteIdxMatches) byteIndices.push(parseInt(b[1], 10));
					let endianness = "little";
					if (rhs.match(/data\[\d+\]\s*<<\s*8/)) {
						if (rhs.search(/data\[\d+\]\s*<<\s*8/) < rhs.search(/data\[\d+\](?!\s*<<)/)) endianness = "big";
						else endianness = "little";
					}
					const startByte = byteIndices.length > 0 ? Math.min(...byteIndices) : 0;
					const numBytes = byteIndices.length > 0 ? byteIndices.length : 1;
					const isSigned = line.includes("int16_t") || line.includes("int8_t") || line.includes("int32_t");
					varExtractionMap.set(varName, {
						rawExpr: rhs,
						endianness,
						startByte,
						numBytes,
						isSigned
					});
				} else varMathMap.set(varName, rhs);
			}
		}
		const propAssignments = findPropertyAssignments(blockCode);
		for (const pa of propAssignments) {
			const vhalProp = resolveProperty(pa.propertyIdentifier);
			const valueExpression = pa.valueExpression.trim();
			const { signalName, transform, startByte, numBytes, endianness, isSigned } = resolveSignalAndTransform(valueExpression, varExtractionMap, varMathMap, vhalProp.name);
			const signalId = `${canMessage.hexId}:${signalName}`;
			let signal = canMessage.signals.find((s) => s.name === signalName);
			if (!signal) {
				signal = {
					id: signalId,
					name: signalName,
					messageId: canMessage.id,
					messageName: canMessage.name,
					startBit: startByte * 8,
					length: numBytes * 8,
					endianness,
					isSigned,
					scale: transform.scaleMultiplier,
					offset: transform.offsetAddition,
					min: 0,
					max: 100,
					unit: vhalProp.defaultUnit,
					receiver: "VHAL",
					comment: `Reconstructed from C++: ${valueExpression}`
				};
				canMessage.signals.push(signal);
			}
			const connectionId = `conn_${signal.id}_${vhalProp.name}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
			connections.push({
				id: connectionId,
				sourceSignalId: signal.id,
				targetPropertyId: vhalProp.name,
				canMessageId: canMessage.id,
				signal,
				property: vhalProp,
				transform,
				notes: `Reverse-engineered from C++ expression: ${valueExpression}`,
				createdSource: "reverse_cpp"
			});
		}
	}
	return {
		messages,
		connections,
		reconstructedProperties,
		warnings,
		totalParsedSignals: messages.reduce((acc, m) => acc + m.signals.length, 0)
	};
}
function findPropertyAssignments(blockCode) {
	const assignments = [];
	const propAssignRegex = /(?:([a-zA-Z0-9_]+)\.prop\s*=\s*(?:static_cast<[^>]+>\s*)?\((?:VehicleProperty::([a-zA-Z0-9_]+)|(0x[0-9a-fA-F]+))\)|(?:([a-zA-Z0-9_]+)\.prop\s*=\s*(?:VehicleProperty::([a-zA-Z0-9_]+)|(0x[0-9a-fA-F]+))))/g;
	let paMatch;
	while ((paMatch = propAssignRegex.exec(blockCode)) !== null) {
		const varName = paMatch[1] || paMatch[4];
		const propName = paMatch[2] || paMatch[5] || paMatch[3] || paMatch[6];
		if (!propName) continue;
		const afterCode = blockCode.slice(paMatch.index);
		const valueMatch = afterCode.match(new RegExp(`${varName}\\.value\\.(?:floatValues|int32Values|booleanValues|int64Values)\\s*=\\s*\\{?\\s*([^;\\}]+)\\s*\\}?;`));
		const pushMatch = afterCode.match(new RegExp(`${varName}\\.value\\.(?:floatValues|int32Values|booleanValues|int64Values)\\.push_back\\(\\s*([^\\)]+)\\s*\\);`));
		const expr = valueMatch ? valueMatch[1] : pushMatch ? pushMatch[1] : "";
		if (expr) assignments.push({
			propertyIdentifier: propName,
			valueExpression: expr.trim()
		});
	}
	const callRegex = /(?:dispatch|send|publish|create|emit|set)(?:Vehicle)?Property(?:Value)?\s*\(\s*(?:VehicleProperty::([a-zA-Z0-9_]+)|(0x[0-9a-fA-F]+))\s*,\s*([^,\);]+)/g;
	let callMatch;
	while ((callMatch = callRegex.exec(blockCode)) !== null) {
		const propName = callMatch[1] || callMatch[2];
		const expr = callMatch[3];
		if (propName && expr) assignments.push({
			propertyIdentifier: propName,
			valueExpression: expr.trim()
		});
	}
	const structInitRegex = /VehicleProperty::([A-Za-z0-9_]+)[^;]*?(?:floatValues|int32Values|booleanValues)\s*=\s*\{?\s*([^;\}]+)\s*\}?/g;
	let structMatch;
	while ((structMatch = structInitRegex.exec(blockCode)) !== null) {
		const propName = structMatch[1];
		const expr = structMatch[2];
		if (!assignments.some((a) => a.propertyIdentifier === propName)) assignments.push({
			propertyIdentifier: propName,
			valueExpression: expr.trim()
		});
	}
	return assignments;
}
function resolveSignalAndTransform(valueExpression, varExtractionMap, varMathMap, targetPropertyName) {
	let expr = valueExpression;
	let rawVarName = "";
	for (const rawName of varExtractionMap.keys()) if (expr.includes(rawName)) {
		rawVarName = rawName;
		break;
	}
	let passCount = 0;
	while (!rawVarName && passCount < 6) {
		passCount++;
		let substituted = false;
		for (const [mathName, mathExpr] of varMathMap.entries()) if (expr.includes(mathName)) {
			expr = expr.split(mathName).join(`(${mathExpr})`);
			substituted = true;
		}
		for (const rawName of varExtractionMap.keys()) if (expr.includes(rawName)) {
			rawVarName = rawName;
			break;
		}
		if (!substituted) break;
	}
	const extraction = rawVarName ? varExtractionMap.get(rawVarName) : void 0;
	const startByte = extraction ? extraction.startByte : 0;
	const numBytes = extraction ? extraction.numBytes : 2;
	const endianness = extraction ? extraction.endianness : "little";
	const isSigned = extraction ? extraction.isSigned : false;
	let signalName = "";
	if (rawVarName) {
		signalName = rawVarName.replace(/^raw_?/, "").replace(/^([a-z])/, (m) => m.toUpperCase());
		signalName = `Sig_${signalName}`;
	} else signalName = `Sig_${targetPropertyName}`;
	let scaleMultiplier = 1;
	let offsetAddition = 0;
	let customExpression = expr;
	if (rawVarName) customExpression = expr.split(rawVarName).join("raw");
	customExpression = customExpression.replace(/static_cast<[^>]+>\(([^)]+)\)/g, "$1");
	const scaleMulMatch = customExpression.match(/raw\s*\*\s*([0-9.]+)(?:f)?/);
	if (scaleMulMatch) scaleMultiplier = parseFloat(scaleMulMatch[1]);
	const scaleDivMatch = customExpression.match(/raw(?:\s*\*\s*[0-9.]+f?)?\s*\/\s*([0-9.]+)(?:f)?/);
	if (scaleDivMatch) {
		const divisor = parseFloat(scaleDivMatch[1]);
		if (divisor !== 0) scaleMultiplier = scaleMultiplier / divisor;
	}
	const offsetMatch = customExpression.match(/([+-]\s*[0-9.]+)(?:f)?(?!\s*\*)/);
	if (offsetMatch) offsetAddition = parseFloat(offsetMatch[1].replace(/\s+/g, ""));
	const transform = {
		scaleMultiplier: isNaN(scaleMultiplier) ? 1 : scaleMultiplier,
		offsetAddition: isNaN(offsetAddition) ? 0 : offsetAddition,
		customExpression: customExpression.trim(),
		targetTypeCast: targetPropertyName.includes("SPEED") || targetPropertyName.includes("RPM") || targetPropertyName.includes("TEMP") ? "float" : "int32_t"
	};
	return {
		signalName,
		transform,
		startByte,
		numBytes,
		endianness,
		isSigned
	};
}
var SAMPLE_VENDOR_VHAL_CPP = `// CAN-to-AOSP VHAL Translation Implementation
// Target Architecture: Android Automotive OS AIDL IVehicle
#include <aidl/android/hardware/automotive/vehicle/VehicleProperty.h>
#include <aidl/android/hardware/automotive/vehicle/VehiclePropValue.h>
#include <linux/can.h>
#include <cstdint>

using aidl::android::hardware::automotive::vehicle::VehicleProperty;
using aidl::android::hardware::automotive::vehicle::VehiclePropValue;

void CanVhalHalService::onCanFrameReceived(const struct can_frame& frame) {
    switch (frame.can_id) {
        // Message: VehicleDynamics (0x1A4)
        case 0x1A4: {
            // Motorola Big-Endian speed unpacking
            uint16_t raw_speed = (frame.data[0] << 8) | frame.data[1];
            float speed_kmh = raw_speed * 0.01f;
            float speed_mps = speed_kmh / 3.6f;

            VehiclePropValue propSpeed;
            propSpeed.prop = static_cast<int32_t>(VehicleProperty::PERF_VEHICLE_SPEED);
            propSpeed.areaId = 0;
            propSpeed.value.floatValues = { speed_mps };
            mCallback->onPropertyEvent({ propSpeed });

            // Steering angle
            int16_t raw_steering = static_cast<int16_t>((frame.data[2] << 8) | frame.data[3]);
            float steering_deg = raw_steering * 0.1f;

            VehiclePropValue propSteer;
            propSteer.prop = static_cast<int32_t>(VehicleProperty::PERF_STEERING_ANGLE);
            propSteer.areaId = 0;
            propSteer.value.floatValues = { steering_deg };
            mCallback->onPropertyEvent({ propSteer });

            // Brake pedal position
            uint8_t raw_brake = frame.data[4];
            float brake_pct = raw_brake * 0.39215686f;

            VehiclePropValue propBrake;
            propBrake.prop = static_cast<int32_t>(VehicleProperty::BRAKE_PEDAL_POSITION);
            propBrake.areaId = 0;
            propBrake.value.floatValues = { brake_pct };
            mCallback->onPropertyEvent({ propBrake });
            break;
        }

        // Message: EngineStatus (0x1F4)
        case 0x1F4: {
            // Intel Little-Endian engine RPM
            uint16_t raw_rpm = frame.data[0] | (frame.data[1] << 8);
            float rpm = raw_rpm * 0.25f;

            VehiclePropValue propRpm;
            propRpm.prop = static_cast<int32_t>(VehicleProperty::ENGINE_RPM);
            propRpm.areaId = 0;
            propRpm.value.floatValues = { rpm };
            mCallback->onPropertyEvent({ propRpm });

            // Engine Coolant Temperature
            uint8_t raw_coolant = frame.data[2];
            float coolant_temp = static_cast<float>(raw_coolant) - 40.0f;

            VehiclePropValue propCoolant;
            propCoolant.prop = static_cast<int32_t>(VehicleProperty::ENGINE_COOLANT_TEMP);
            propCoolant.areaId = 0;
            propCoolant.value.floatValues = { coolant_temp };
            mCallback->onPropertyEvent({ propCoolant });

            // Parking brake boolean status
            bool is_parked = (frame.data[5] & 0x01) != 0;

            VehiclePropValue propPark;
            propPark.prop = static_cast<int32_t>(VehicleProperty::PARKING_BRAKE_ON);
            propPark.areaId = 0;
            propPark.value.booleanValues = { is_parked };
            mCallback->onPropertyEvent({ propPark });
            break;
        }

        // Message: BatteryManagement (0x262)
        case 0x262: {
            uint16_t raw_batt = frame.data[0] | (frame.data[1] << 8);
            float batt_wh = raw_batt * 10.0f;

            VehiclePropValue propBatt;
            propBatt.prop = static_cast<int32_t>(VehicleProperty::EV_BATTERY_LEVEL);
            propBatt.areaId = 0;
            propBatt.value.floatValues = { batt_wh };
            mCallback->onPropertyEvent({ propBatt });

            bool is_plugged = (frame.data[4] & 0x01) != 0;
            VehiclePropValue propPlug;
            propPlug.prop = static_cast<int32_t>(VehicleProperty::EV_CHARGE_PORT_CONNECTED);
            propPlug.areaId = 0;
            propPlug.value.booleanValues = { is_plugged };
            mCallback->onPropertyEvent({ propPlug });
            break;
        }

        default:
            // Unmapped CAN message ID
            break;
    }
}
`;
//#endregion
//#region src/codegen/cppSynthesizer.ts
function synthesizeVhalCpp(connections, options = {}) {
	const { serviceClassName = "CanVhalHalService", namespace = "aidl::android::hardware::automotive::vehicle::impl", includeSafetyGuards = true, generateComments = true } = options;
	if (connections.length === 0) return `// ============================================================================
// CAN-to-AOSP VHAL Auto-Generated Translation Unit
// Status: No active CAN-to-VHAL mappings configured.
// ============================================================================
// Add signals to the canvas and create connections to generate production C++ code.
`;
	const messageGroups = /* @__PURE__ */ new Map();
	for (const conn of connections) {
		const msgId = conn.canMessageId;
		if (!messageGroups.has(msgId)) messageGroups.set(msgId, {
			hexId: `0x${msgId.toString(16).toUpperCase()}`,
			msgName: conn.signal.messageName || `MSG_0x${msgId.toString(16).toUpperCase()}`,
			conns: []
		});
		messageGroups.get(msgId).conns.push(conn);
	}
	const caseBlocks = [];
	for (const [msgId, group] of messageGroups.entries()) {
		const signalBlocks = [];
		for (const conn of group.conns) {
			const sig = conn.signal;
			const prop = conn.property;
			const tf = conn.transform;
			const varPrefix = sanitizeIdentifier(sig.name);
			const unpackCode = generateSignalUnpack(sig, varPrefix);
			const mathCode = generateMathTransform(sig, prop, tf, varPrefix);
			const propDispatchCode = generatePropDispatch(prop, varPrefix);
			signalBlocks.push(`            // Signal: ${sig.name} -> VehicleProperty::${prop.name}
${unpackCode}
${mathCode}
${propDispatchCode}`);
		}
		const caseBody = signalBlocks.join("\n\n");
		caseBlocks.push(`        // --------------------------------------------------------------------
        // CAN Frame: ${group.msgName} (${group.hexId})
        // --------------------------------------------------------------------
        case ${group.hexId}: {
${includeSafetyGuards ? `            if (frame.can_dlc < 8) {\n                // Frame DLC safety verification\n                break;\n            }\n\n` : ""}${caseBody}
            break;
        }`);
	}
	return `// ============================================================================
// AUTO-GENERATED BY CAN-TO-AOSP VHAL STUDIO
// Architecture: Android Automotive OS (AAOS / AOSP) AIDL IVehicle
// Compliance: MISRA-C++ / Google C++ Style Guide
// Generated at: ${(/* @__PURE__ */ new Date()).toISOString()}
// Total Mappings: ${connections.length} across ${messageGroups.size} CAN Messages
// ============================================================================

#include <aidl/android/hardware/automotive/vehicle/VehicleProperty.h>
#include <aidl/android/hardware/automotive/vehicle/VehiclePropValue.h>
#include <aidl/android/hardware/automotive/vehicle/RawPropModel.h>
#include <linux/can.h>
#include <utils/SystemClock.h>
#include <cstdint>
#include <vector>

namespace ${namespace} {

using aidl::android::hardware::automotive::vehicle::VehicleProperty;
using aidl::android::hardware::automotive::vehicle::VehiclePropValue;
using aidl::android::hardware::automotive::vehicle::RawPropModel;
using android::elapsedRealtimeNano;

/**
 * @brief Processes incoming raw Linux SocketCAN frames and translates
 *        them into standard AOSP AIDL VehiclePropValue events.
 * @param frame Const reference to raw Linux can_frame.
 */
void ${serviceClassName}::onCanFrameReceived(const struct can_frame& frame) {
    const int64_t timestamp = elapsedRealtimeNano();

    switch (frame.can_id & CAN_EFF_MASK) {
${caseBlocks.join("\n\n")}

        default:
            // Non-mapped CAN frame ID received on bus
            break;
    }
}

} // namespace ${namespace}
`;
}
function sanitizeIdentifier(name) {
	return name.replace(/[^a-zA-Z0-9_]/g, "_").toLowerCase();
}
function generateSignalUnpack(sig, varPrefix) {
	const isLittle = sig.endianness === "little";
	const startByte = Math.floor(sig.startBit / 8);
	const bitOffsetInByte = sig.startBit % 8;
	if (sig.length === 1) return `            const bool raw_${varPrefix} = ((frame.data[${startByte}] >> ${bitOffsetInByte}) & 0x01U) != 0U;`;
	if (sig.length === 8 && bitOffsetInByte === 0) {
		if (sig.isSigned) return `            const int8_t raw_${varPrefix} = static_cast<int8_t>(frame.data[${startByte}]);`;
		return `            const uint8_t raw_${varPrefix} = frame.data[${startByte}];`;
	}
	if (sig.length === 16 && bitOffsetInByte === 0) {
		if (isLittle) {
			const expr = `(static_cast<uint16_t>(frame.data[${startByte}])) | (static_cast<uint16_t>(frame.data[${startByte + 1}]) << 8U)`;
			if (sig.isSigned) return `            const int16_t raw_${varPrefix} = static_cast<int16_t>(${expr});`;
			return `            const uint16_t raw_${varPrefix} = ${expr};`;
		} else {
			const expr = `(static_cast<uint16_t>(frame.data[${startByte}]) << 8U) | (static_cast<uint16_t>(frame.data[${startByte + 1}]))`;
			if (sig.isSigned) return `            const int16_t raw_${varPrefix} = static_cast<int16_t>(${expr});`;
			return `            const uint16_t raw_${varPrefix} = ${expr};`;
		}
	}
	const numBytes = Math.ceil((bitOffsetInByte + sig.length) / 8);
	const maskHex = `0x${((1n << BigInt(sig.length)) - 1n).toString(16).toUpperCase()}ULL`;
	if (isLittle) {
		const byteShifts = [];
		for (let b = 0; b < numBytes && startByte + b < 8; b++) byteShifts.push(`(static_cast<uint64_t>(frame.data[${startByte + b}]) << ${b * 8}ULL)`);
		let res = `            const uint64_t raw_bits_${varPrefix} = (${byteShifts.join(" | ")});\n`;
		res += `            const uint64_t raw_${varPrefix} = (raw_bits_${varPrefix} >> ${bitOffsetInByte}ULL) & ${maskHex};`;
		return res;
	} else {
		const byteShifts = [];
		for (let b = 0; b < numBytes && startByte + b < 8; b++) {
			const shift = (numBytes - 1 - b) * 8;
			byteShifts.push(`(static_cast<uint64_t>(frame.data[${startByte + b}]) << ${shift}ULL)`);
		}
		let res = `            const uint64_t raw_bits_${varPrefix} = (${byteShifts.join(" | ")});\n`;
		res += `            const uint64_t raw_${varPrefix} = (raw_bits_${varPrefix} >> ${bitOffsetInByte}ULL) & ${maskHex};`;
		return res;
	}
}
function generateMathTransform(sig, prop, tf, varPrefix) {
	if (sig.length === 1 && prop.dataType === "booleanValues") return `            const bool val_${varPrefix} = raw_${varPrefix};`;
	if (tf.customExpression && tf.customExpression.trim() && tf.customExpression.includes("raw")) return `            // Custom engineering arithmetic\n            const float val_${varPrefix} = ${tf.customExpression.replace(/\braw\b/g, `static_cast<float>(raw_${varPrefix})`).replace(/f\b/g, "f")};`;
	const scale = sig.scale !== void 0 ? sig.scale : 1;
	const offset = sig.offset !== void 0 ? sig.offset : 0;
	const multiplier = tf.scaleMultiplier !== void 0 ? tf.scaleMultiplier : 1;
	const addition = tf.offsetAddition !== void 0 ? tf.offsetAddition : 0;
	const totalScale = scale * multiplier;
	const totalOffset = offset + addition;
	if (totalScale === 1 && totalOffset === 0) {
		if (prop.dataType === "int32Values" || prop.dataType === "int64Values") return `            const auto val_${varPrefix} = raw_${varPrefix};`;
		return `            const float val_${varPrefix} = static_cast<float>(raw_${varPrefix});`;
	}
	return `            const float val_${varPrefix} = (static_cast<float>(raw_${varPrefix}) * ${Number.isInteger(totalScale) ? `${totalScale}.0f` : `${totalScale}f`})${totalOffset > 0 ? ` + ${Number.isInteger(totalOffset) ? `${totalOffset}.0f` : `${totalOffset}f`}` : totalOffset < 0 ? ` - ${Math.abs(totalOffset)}f` : ""};`;
}
function generatePropDispatch(prop, varPrefix) {
	let valueVectorInit = "";
	switch (prop.dataType) {
		case "floatValues":
			valueVectorInit = `prop_${varPrefix}.value.floatValues = { static_cast<float>(val_${varPrefix}) };`;
			break;
		case "int32Values":
			valueVectorInit = `prop_${varPrefix}.value.int32Values = { static_cast<int32_t>(val_${varPrefix}) };`;
			break;
		case "booleanValues":
			valueVectorInit = `prop_${varPrefix}.value.booleanValues = { static_cast<bool>(val_${varPrefix}) };`;
			break;
		case "int64Values":
			valueVectorInit = `prop_${varPrefix}.value.int64Values = { static_cast<int64_t>(val_${varPrefix}) };`;
			break;
		default: valueVectorInit = `prop_${varPrefix}.value.floatValues = { static_cast<float>(val_${varPrefix}) };`;
	}
	return `            VehiclePropValue prop_${varPrefix};
            prop_${varPrefix}.prop = static_cast<int32_t>(VehicleProperty::${prop.name});
            prop_${varPrefix}.areaId = 0;
            prop_${varPrefix}.timestamp = timestamp;
            ${valueVectorInit}
            mCallback->onPropertyEvent({ prop_${varPrefix} });`;
}
//#endregion
//#region scripts/verify_engine.ts
var passed = 0;
var failed = 0;
function assert(condition, message) {
	if (condition) {
		console.log(`  ✓ PASS: ${message}`);
		passed++;
	} else {
		console.error(`  ✗ FAIL: ${message}`);
		failed++;
	}
}
console.log("\n======================================================");
console.log("1. TESTING AOSP AIDL VehicleProperty CATALOG");
console.log("======================================================");
assert(AOSP_VHAL_CATALOG.length >= 25, `Catalog loaded with ${AOSP_VHAL_CATALOG.length} properties`);
var speedProp = getVhalPropertyByName("PERF_VEHICLE_SPEED");
assert(speedProp !== void 0, "Found PERF_VEHICLE_SPEED by name");
assert(speedProp?.hexId === "0x11600207", `PERF_VEHICLE_SPEED hex ID is 0x11600207`);
assert(speedProp?.dataType === "floatValues", "PERF_VEHICLE_SPEED data type is floatValues");
assert(speedProp?.defaultUnit === "m/s", "PERF_VEHICLE_SPEED default unit is m/s");
var rpmProp = getVhalPropertyByName("ENGINE_RPM");
assert(rpmProp?.hexId === "0x11600205", "ENGINE_RPM hex ID is 0x11600205");
assert(rpmProp?.domain === "Powertrain", "ENGINE_RPM domain is Powertrain");
assert(getVhalPropertyByHexId("0x11600207")?.name === "PERF_VEHICLE_SPEED", "Lookup by hex ID 0x11600207 succeeded");
console.log("\n======================================================");
console.log("2. TESTING DBC PARSER (FR-1.1 & FR-1.2)");
console.log("======================================================");
var dbcResult = parseDbc(SAMPLE_POWERTRAIN_DBC);
assert(dbcResult.messages.length === 5, `Parsed 5 CAN messages (got ${dbcResult.messages.length})`);
assert(dbcResult.totalSignals >= 20, `Parsed ${dbcResult.totalSignals} total signals`);
var dynamicsMsg = dbcResult.messages.find((m) => m.id === 420);
assert(dynamicsMsg !== void 0, "Found VehicleDynamics message (ID 420)");
assert(dynamicsMsg?.signals.length === 6, `VehicleDynamics has 6 signals (got ${dynamicsMsg?.signals.length})`);
var speedSig = dynamicsMsg?.signals.find((s) => s.name === "VehicleSpeed");
assert(speedSig !== void 0, "Found VehicleSpeed signal in message 420");
assert(speedSig?.endianness === "big", "VehicleSpeed endianness is Motorola (@0+) / big-endian");
assert(speedSig?.scale === .01, `VehicleSpeed scale is 0.01 (got ${speedSig?.scale})`);
assert(speedSig?.unit === "km/h", `VehicleSpeed unit is km/h (got ${speedSig?.unit})`);
var steerSig = dynamicsMsg?.signals.find((s) => s.name === "SteeringWheelAngle");
assert(steerSig?.isSigned === true, "SteeringWheelAngle is signed (@0-)");
assert(steerSig?.scale === .1, "SteeringWheelAngle scale is 0.1");
var rpmSig = dbcResult.messages.find((m) => m.id === 500)?.signals.find((s) => s.name === "EngineSpeed");
assert(rpmSig?.endianness === "little", "EngineSpeed endianness is Intel (@1+) / little-endian");
assert(rpmSig?.scale === .25, `EngineSpeed scale is 0.25 (got ${rpmSig?.scale})`);
var jsonResult = parseJsonMatrix(JSON.stringify([{
	id: "0x350",
	name: "RadarTrack",
	dlc: 8,
	sender: "RADAR",
	signals: [{
		name: "TargetDistance",
		start_bit: 0,
		bit_length: 16,
		byte_order: "intel",
		scale: .1,
		offset: 0,
		unit: "m"
	}]
}]));
assert(jsonResult.messages.length === 1, "JSON matrix parsed 1 message");
assert(jsonResult.messages[0].signals[0].name === "TargetDistance", "Parsed TargetDistance signal from JSON");
assert(jsonResult.messages[0].signals[0].scale === .1, "JSON signal scale is 0.1");
console.log("\n======================================================");
console.log("3. TESTING REVERSE ENGINEERING ENGINE (FR-2.1 & FR-2.2)");
console.log("======================================================");
var reverseResult = parseCppVhalCode(SAMPLE_VENDOR_VHAL_CPP);
assert(reverseResult.messages.length === 3, `Reverse parsed 3 CAN message branches (got ${reverseResult.messages.length})`);
assert(reverseResult.connections.length >= 7, `Reverse reconstructed ${reverseResult.connections.length} connections (expected >= 7)`);
var speedConn = reverseResult.connections.find((c) => c.property.name === "PERF_VEHICLE_SPEED");
assert(speedConn !== void 0, "Reverse engineered connection to PERF_VEHICLE_SPEED");
assert(speedConn?.canMessageId === 420, `Mapped CAN Message ID is 0x1A4 (got 0x${speedConn?.canMessageId.toString(16)})`);
assert(speedConn?.signal.endianness === "big", "Vehicle speed correctly recognized as Motorola Big Endian from frame.data[0] << 8 | frame.data[1]");
assert(speedConn?.transform.customExpression.includes("3.6"), `Extracted km/h to m/s conversion (/ 3.6): ${speedConn?.transform.customExpression}`);
var rpmConn = reverseResult.connections.find((c) => c.property.name === "ENGINE_RPM");
assert(rpmConn !== void 0, "Reverse engineered connection to ENGINE_RPM");
assert(rpmConn?.canMessageId === 500, "Mapped to Message 0x1F4");
assert(rpmConn?.signal.endianness === "little", "RPM correctly recognized as Intel Little Endian from frame.data[0] | frame.data[1] << 8");
assert(reverseResult.connections.find((c) => c.property.name === "PARKING_BRAKE_ON") !== void 0, "Reverse engineered boolean connection to PARKING_BRAKE_ON");
console.log("\n======================================================");
console.log("4. TESTING FORWARD CODE SYNTHESIZER (FR-4.1 & NFR-3)");
console.log("======================================================");
var generatedCpp = synthesizeVhalCpp(reverseResult.connections, {
	serviceClassName: "CanVhalHalService",
	includeSafetyGuards: true,
	generateComments: true
});
assert(generatedCpp.includes("void CanVhalHalService::onCanFrameReceived(const struct can_frame& frame)"), "Contains standard onCanFrameReceived function signature");
assert(generatedCpp.includes("case 0x1A4:"), "Contains switch case for 0x1A4");
assert(generatedCpp.includes("case 0x1F4:"), "Contains switch case for 0x1F4");
assert(generatedCpp.includes("case 0x262:"), "Contains switch case for 0x262");
assert(generatedCpp.includes("VehicleProperty::PERF_VEHICLE_SPEED"), "Populates VehicleProperty::PERF_VEHICLE_SPEED");
assert(generatedCpp.includes("VehicleProperty::ENGINE_RPM"), "Populates VehicleProperty::ENGINE_RPM");
assert(generatedCpp.includes("mCallback->onPropertyEvent"), "Dispatches via mCallback->onPropertyEvent");
assert(generatedCpp.includes("if (frame.can_dlc < 8)"), "Includes DLC safety bounds checking");
console.log("\n======================================================");
console.log("5. TESTING HIGH-CAPACITY PERFORMANCE LOAD (FR-3.3)");
console.log("======================================================");
var stressConns = [];
for (let i = 0; i < 150; i++) {
	const catalogProp = AOSP_VHAL_CATALOG[i % AOSP_VHAL_CATALOG.length];
	stressConns.push({
		id: `stress_${i}`,
		sourceSignalId: `0x100:Sig_${i}`,
		targetPropertyId: `${catalogProp.name}_${i}`,
		canMessageId: 256 + Math.floor(i / 10),
		signal: {
			id: `0x100:Sig_${i}`,
			name: `Sig_${i}`,
			messageId: 256 + Math.floor(i / 10),
			messageName: `FRAME_${Math.floor(i / 10)}`,
			startBit: i % 8 * 8,
			length: 16,
			endianness: i % 2 === 0 ? "little" : "big",
			isSigned: false,
			scale: .1,
			offset: 0,
			min: 0,
			max: 1e3,
			unit: "m/s"
		},
		property: {
			...catalogProp,
			name: `${catalogProp.name}_${i}`,
			id: catalogProp.id + i,
			hexId: `0x${(catalogProp.id + i).toString(16).toUpperCase()}`
		},
		transform: {
			scaleMultiplier: 1,
			offsetAddition: 0,
			customExpression: "raw * 0.1f",
			targetTypeCast: "float"
		},
		createdSource: "manual"
	});
}
var startTime = performance.now();
var stressCpp = synthesizeVhalCpp(stressConns);
var endTime = performance.now();
assert(stressConns.length === 150, "150 active mapping connections prepared");
assert(stressCpp.length > 5e3, `Synthesized C++ code length for 150 connections is ${stressCpp.length} bytes`);
assert(endTime - startTime < 100, `C++ code generation for 150 connections took ${(endTime - startTime).toFixed(2)}ms (< 100ms)`);
console.log("\n======================================================");
console.log(`TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
console.log("======================================================\n");
if (failed > 0) process.exit(1);
//#endregion
export {};
